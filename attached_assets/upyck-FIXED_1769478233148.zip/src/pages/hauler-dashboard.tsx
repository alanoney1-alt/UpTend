import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useGeoLocation } from "@/hooks/use-geolocation";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { PyckerVehicle } from "@shared/schema";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar";
import {
  Truck, LayoutDashboard, ClipboardList, Calendar, DollarSign,
  User, Settings, Bell, MapPin, Clock, Package, CheckCircle,
  X, Star, Phone, MessageCircle, Navigation, Timer, CreditCard,
  ExternalLink, Loader2, AlertCircle, Shield, UserCheck, CircleDollarSign,
  ClipboardCheck, Plus, Minus, Camera, AlertTriangle, Upload, Image, Flag
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ServiceRequestWithDetails, HaulerWithProfile } from "@shared/schema";

import hauler1 from "@assets/stock_images/professional_male_wo_ae620e83.jpg";
import { NdaAgreementModal } from "@/components/nda-agreement-modal";
import { FileText } from "lucide-react";

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "requests", label: "Job Requests", icon: ClipboardList, badge: 3 },
  { id: "schedule", label: "Schedule", icon: Calendar },
  { id: "earnings", label: "Earnings", icon: DollarSign },
  { id: "rebates", label: "Green Guarantee", icon: Flag },
  { id: "profile", label: "Profile", icon: User },
  { id: "settings", label: "Settings", icon: Settings },
];

function JobRequestCard({ request, onAccept, onDecline, canAcceptJobs = false, isAccepting = false }: { 
  request: ServiceRequestWithDetails; 
  onAccept: () => void;
  onDecline: () => void;
  canAcceptJobs?: boolean;
  isAccepting?: boolean;
}) {
  const serviceLabels: Record<string, string> = {
    junk_removal: "Junk Removal",
    furniture_moving: "Furniture Moving",
    garage_cleanout: "Garage Cleanout",
    estate_cleanout: "Estate Cleanout",
    truck_unloading: "U-Haul/Truck Unloading",
  };

  const loadLabels: Record<string, string> = {
    small: "Small Load",
    medium: "Medium Load",
    large: "Large Load",
    extra_large: "Extra Large",
  };

  const isContactMasked = !request.acceptedAt;
  const customerName = request.customer ? `${request.customer.firstName || ''} ${request.customer.lastName || ''}`.trim() : 'Customer';
  const maskedName = (request.customer?.firstName || 'Customer').split(" ")[0] + " ***";

  return (
    <Card className="p-5 hover-elevate" data-testid={`card-job-${request.id}`}>
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10">
            <AvatarFallback>{request.customer?.firstName?.charAt(0) || "C"}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">{isContactMasked ? maskedName : customerName}</h3>
            <p className="text-sm text-muted-foreground">
              {serviceLabels[request.serviceType] || request.serviceType}
            </p>
          </div>
        </div>
        <Badge variant="secondary" className="shrink-0">
          <Clock className="w-3 h-3 mr-1" />
          {request.scheduledFor === "asap" ? "ASAP" : request.scheduledFor}
        </Badge>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-start gap-2 text-sm">
          <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
          <span>{request.pickupAddress}, {request.pickupCity} {request.pickupZip}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Package className="w-4 h-4 text-muted-foreground shrink-0" />
          <span>{loadLabels[request.loadEstimate] || request.loadEstimate}</span>
        </div>
        {request.description && (
          <p className="text-sm text-muted-foreground pl-6 line-clamp-2">
            {request.description}
          </p>
        )}
      </div>

      <div className="flex items-center justify-between pt-4 border-t">
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Navigation className="w-4 h-4 text-muted-foreground" />
            <span>3.2 mi</span>
          </div>
          <div className="flex items-center gap-1 text-status-online">
            <Timer className="w-4 h-4" />
            <span>12 min</span>
          </div>
        </div>
        <div className="font-bold text-lg">${request.priceEstimate || 129}</div>
      </div>

      {isContactMasked && (
        <p className="text-xs text-muted-foreground bg-muted p-2 rounded mt-4">
          <Shield className="w-3 h-3 inline mr-1" />
          Full contact info released after accepting job
        </p>
      )}

      <div className="flex gap-3 mt-4">
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={onDecline}
          data-testid={`button-decline-${request.id}`}
        >
          <X className="w-4 h-4 mr-2" />
          Decline
        </Button>
        <Button 
          className="flex-1"
          onClick={onAccept}
          disabled={!canAcceptJobs || isAccepting}
          data-testid={`button-accept-${request.id}`}
        >
          {isAccepting ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <CheckCircle className="w-4 h-4 mr-2" />
          )}
          {!canAcceptJobs ? "Complete Compliance" : "Accept"}
        </Button>
      </div>
    </Card>
  );
}

function ItemVerificationCard({ 
  originalItems, 
  onVerified 
}: { 
  originalItems: { id: string; label: string; quantity: number; price: number }[];
  onVerified: (verified: boolean, adjustments: { added: typeof originalItems; removed: string[]; totalAdjustment: number }) => void;
}) {
  const [verifiedItems, setVerifiedItems] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    originalItems.forEach(item => {
      initial[item.id] = item.quantity;
    });
    return initial;
  });
  const [additionalItems, setAdditionalItems] = useState<{ id: string; label: string; quantity: number; price: number }[]>([]);
  const [showAddItem, setShowAddItem] = useState(false);

  const originalTotal = originalItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  const verifiedTotal = originalItems.reduce((sum, item) => {
    const qty = verifiedItems[item.id] || 0;
    return sum + (item.price * qty);
  }, 0) + additionalItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const adjustment = verifiedTotal - originalTotal;
  const hasDiscrepancy = adjustment !== 0;

  const updateQuantity = (itemId: string, delta: number) => {
    setVerifiedItems(prev => ({
      ...prev,
      [itemId]: Math.max(0, (prev[itemId] || 0) + delta)
    }));
  };

  return (
    <Card className="p-5" data-testid="card-item-verification">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <ClipboardCheck className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold">Verify Items On-Site</h3>
          <p className="text-sm text-muted-foreground">Confirm items match customer's list</p>
        </div>
      </div>

      <div className="p-3 mb-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-400">
            <span className="font-medium">Important:</span> Adjust quantities below to match what's actually on-site. 
            Customer will be notified of any price changes before you start.
          </p>
        </div>
      </div>

      <div className="space-y-2 mb-4 max-h-60 overflow-y-auto">
        {originalItems.map((item) => {
          const currentQty = verifiedItems[item.id] || 0;
          const originalQty = item.quantity;
          const isDifferent = currentQty !== originalQty;
          
          return (
            <div
              key={item.id}
              className={`flex items-center justify-between p-3 rounded-lg border ${
                isDifferent ? "border-amber-500 bg-amber-50 dark:bg-amber-900/20" : "border-border"
              }`}
            >
              <div className="flex items-center gap-3">
                <Package className="w-4 h-4 text-muted-foreground" />
                <div>
                  <span className="text-sm font-medium">{item.label}</span>
                  <span className="text-xs text-muted-foreground ml-2">(${item.price} ea)</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isDifferent && (
                  <Badge variant="outline" className="text-amber-600 border-amber-500 text-xs">
                    was {originalQty}
                  </Badge>
                )}
                <div className="flex items-center gap-1">
                  <Button
                    type="button"
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    onClick={() => updateQuantity(item.id, -1)}
                    data-testid={`button-verify-minus-${item.id}`}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="w-8 text-center text-sm font-medium">{currentQty}</span>
                  <Button
                    type="button"
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    onClick={() => updateQuantity(item.id, 1)}
                    data-testid={`button-verify-plus-${item.id}`}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
        
        {additionalItems.map((item, idx) => (
          <div
            key={`added-${idx}`}
            className="flex items-center justify-between p-3 rounded-lg border border-green-500 bg-green-50 dark:bg-green-900/20"
          >
            <div className="flex items-center gap-3">
              <Plus className="w-4 h-4 text-green-600" />
              <div>
                <span className="text-sm font-medium">{item.label}</span>
                <span className="text-xs text-muted-foreground ml-2">(${item.price} ea)</span>
              </div>
            </div>
            <Badge variant="outline" className="text-green-600 border-green-500">
              +{item.quantity} added
            </Badge>
          </div>
        ))}
      </div>

      <div className={`p-4 rounded-lg ${hasDiscrepancy ? "bg-amber-500/10 border border-amber-500/30" : "bg-muted"}`}>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-muted-foreground">Original Quote:</span>
          <span className="font-medium">${originalTotal}</span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-muted-foreground">Verified Total:</span>
          <span className="font-bold text-lg">${verifiedTotal}</span>
        </div>
        {hasDiscrepancy && (
          <div className={`flex justify-between items-center pt-2 border-t ${adjustment > 0 ? "text-amber-600" : "text-green-600"}`}>
            <span className="text-sm font-medium">Adjustment:</span>
            <span className="font-bold">{adjustment > 0 ? "+" : ""}{adjustment}</span>
          </div>
        )}
      </div>

      <div className="flex gap-3 mt-4">
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={() => setShowAddItem(true)}
          data-testid="button-add-unlisted-item"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Unlisted Item
        </Button>
        <Button
          className="flex-1"
          onClick={() => {
            const removed = originalItems
              .filter(item => (verifiedItems[item.id] || 0) < item.quantity)
              .map(item => item.id);
            onVerified(!hasDiscrepancy || adjustment > 0, {
              added: additionalItems,
              removed,
              totalAdjustment: adjustment
            });
          }}
          data-testid="button-confirm-verification"
        >
          <CheckCircle className="w-4 h-4 mr-2" />
          {hasDiscrepancy ? "Send Adjustment to Customer" : "Items Match - Start Job"}
        </Button>
      </div>
      
      {hasDiscrepancy && adjustment > 0 && (
        <p className="text-xs text-amber-600 dark:text-amber-400 text-center mt-3">
          Customer must approve the ${adjustment} upcharge before you can start the job.
        </p>
      )}
    </Card>
  );
}

interface ActiveJob {
  id: string;
  customerName: string;
  customerPhone: string;
  pickupAddress: string;
  pickupCity: string;
  pickupZip: string;
  serviceType: string;
  loadEstimate: string;
  priceEstimate: number;
  status: string;
  acceptedAt?: string;
  contactRequiredBy?: string;
  contactConfirmedAt?: string;
  paymentStatus?: string;
}

function ActiveJobCard({ 
  job,
  onPhotoUpload,
  onReportIssue,
  onCompleteJob,
  onConfirmCall,
  isUploading = false,
  uploadedPhotos = [],
  isConfirmingCall = false,
}: { 
  job: ActiveJob;
  onPhotoUpload: (files: FileList) => void;
  onReportIssue: (issue: { type: string; description: string }) => void;
  onCompleteJob: () => void;
  onConfirmCall: () => void;
  isUploading?: boolean;
  uploadedPhotos?: string[];
  isConfirmingCall?: boolean;
}) {
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [issueType, setIssueType] = useState("access");
  const [issueDescription, setIssueDescription] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [callTimeLeft, setCallTimeLeft] = useState<number>(0);
  
  // Calculate call deadline countdown
  useEffect(() => {
    if (!job.acceptedAt || job.contactConfirmedAt) return;
    
    const deadline = job.contactRequiredBy 
      ? new Date(job.contactRequiredBy).getTime()
      : new Date(job.acceptedAt).getTime() + 5 * 60 * 1000;
    
    const updateTimer = () => {
      const remaining = Math.max(0, deadline - Date.now());
      setCallTimeLeft(remaining);
    };
    
    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [job.acceptedAt, job.contactRequiredBy, job.contactConfirmedAt]);
  
  const callMinutes = Math.floor(callTimeLeft / 60000);
  const callSeconds = Math.floor((callTimeLeft % 60000) / 1000);
  const callDeadlineExpired = callTimeLeft === 0 && job.acceptedAt && !job.contactConfirmedAt;

  const serviceLabels: Record<string, string> = {
    junk_removal: "Junk Removal",
    furniture_moving: "Furniture Moving",
    garage_cleanout: "Garage Cleanout",
    estate_cleanout: "Estate Cleanout",
  };

  const handleCallCustomer = () => {
    window.location.href = `tel:${job.customerPhone}`;
  };

  const handleTextCustomer = () => {
    window.location.href = `sms:${job.customerPhone}`;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onPhotoUpload(e.target.files);
    }
  };

  const handleSubmitIssue = () => {
    onReportIssue({ type: issueType, description: issueDescription });
    setShowReportDialog(false);
    setIssueDescription("");
  };

  return (
    <>
      <Card className="p-5" data-testid="card-active-job">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Truck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">Active Job</h3>
              <Badge variant="secondary" className="mt-1">
                {serviceLabels[job.serviceType] || job.serviceType}
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold">${job.priceEstimate}</p>
            <p className="text-xs text-muted-foreground">Your earnings: ${Math.round(job.priceEstimate * 0.8)}</p>
          </div>
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback>{job.customerName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-medium">{job.customerName}</p>
              {job.paymentStatus === "authorized" || job.paymentStatus === "captured" || job.paymentStatus === "completed" ? (
                <p className="text-sm text-muted-foreground">{job.customerPhone}</p>
              ) : (
                <p className="text-sm text-amber-600 dark:text-amber-400">Contact info available after payment</p>
              )}
            </div>
          </div>
          
          <div className="flex items-start gap-2 text-sm">
            <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
            <span>{job.pickupAddress}, {job.pickupCity} {job.pickupZip}</span>
          </div>
        </div>

        <div className="flex gap-2 mb-4">
          {job.paymentStatus === "authorized" || job.paymentStatus === "captured" || job.paymentStatus === "completed" ? (
            <>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={handleCallCustomer}
                data-testid="button-call-customer"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={handleTextCustomer}
                data-testid="button-text-customer"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Text
              </Button>
            </>
          ) : (
            <div className="flex-1 p-3 bg-muted/50 rounded-lg text-center text-sm text-muted-foreground">
              Contact options available after customer payment
            </div>
          )}
        </div>
        
        {/* Call confirmation requirement */}
        {job.acceptedAt && !job.contactConfirmedAt && (
          <div className={`rounded-lg p-3 mb-4 ${callDeadlineExpired ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800' : 'bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800'}`}>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Phone className={`w-5 h-5 ${callDeadlineExpired ? 'text-red-600' : 'text-amber-600'} ${!callDeadlineExpired && 'animate-pulse'}`} />
                <div>
                  <p className={`text-sm font-medium ${callDeadlineExpired ? 'text-red-700 dark:text-red-300' : 'text-amber-700 dark:text-amber-300'}`}>
                    {callDeadlineExpired 
                      ? "Call deadline passed! Please call customer immediately"
                      : "Call customer within"}
                  </p>
                  {!callDeadlineExpired && (
                    <span className="text-lg font-bold font-mono text-amber-600" data-testid="text-pycker-call-countdown">
                      {callMinutes}:{callSeconds.toString().padStart(2, '0')}
                    </span>
                  )}
                </div>
              </div>
              <Button 
                size="sm"
                onClick={onConfirmCall}
                disabled={isConfirmingCall}
                data-testid="button-confirm-call"
              >
                {isConfirmingCall ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-1" />
                    I Called
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
        
        {job.contactConfirmedAt && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3 mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-green-700 dark:text-green-300">
              Customer contacted
            </span>
          </div>
        )}

        <Separator className="my-4" />

        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium mb-2 block">Proof of Completion Photos</Label>
            <p className="text-xs text-muted-foreground mb-3">
              Upload before & after photos to document the job
            </p>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              data-testid="input-photo-upload"
            />
            
            <div className="grid grid-cols-4 gap-2 mb-3">
              {uploadedPhotos.map((photo, idx) => (
                <div 
                  key={idx} 
                  className="aspect-square rounded-lg bg-muted overflow-hidden"
                  data-testid={`uploaded-photo-${idx}`}
                >
                  <img src={photo} alt={`Proof ${idx + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="aspect-square rounded-lg border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center gap-1 hover-elevate transition-colors"
                data-testid="button-add-photo"
              >
                {isUploading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                ) : (
                  <>
                    <Camera className="w-5 h-5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Add</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline"
              className="flex-1"
              onClick={() => setShowReportDialog(true)}
              data-testid="button-report-issue"
            >
              <Flag className="w-4 h-4 mr-2" />
              Report Issue
            </Button>
            <Button 
              className="flex-1"
              disabled={uploadedPhotos.length === 0}
              onClick={onCompleteJob}
              data-testid="button-complete-job"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Complete Job
            </Button>
          </div>
          
          {uploadedPhotos.length === 0 && (
            <p className="text-xs text-amber-600 dark:text-amber-400 text-center">
              Upload at least one photo to complete the job
            </p>
          )}
        </div>
      </Card>

      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report an Issue</DialogTitle>
            <DialogDescription>
              Let us know what problem you've encountered with this job.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Issue Type</Label>
              <Select value={issueType} onValueChange={setIssueType}>
                <SelectTrigger data-testid="select-issue-type">
                  <SelectValue placeholder="Select issue type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="access">Can't access location</SelectItem>
                  <SelectItem value="safety">Safety concern</SelectItem>
                  <SelectItem value="items_different">Items different than described</SelectItem>
                  <SelectItem value="customer_not_present">Customer not present</SelectItem>
                  <SelectItem value="vehicle_issue">Vehicle/equipment issue</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Describe the issue in detail..."
                value={issueDescription}
                onChange={(e) => setIssueDescription(e.target.value)}
                className="min-h-[100px]"
                data-testid="textarea-issue-description"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReportDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitIssue}
              disabled={!issueDescription.trim()}
              data-testid="button-submit-issue"
            >
              Submit Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Completed Job Card with Receipt Upload Prompt
function CompletedJobCard({ 
  job, 
  hasExistingClaim,
  onUploadReceipt 
}: { 
  job: ServiceRequestWithDetails;
  hasExistingClaim: boolean;
  onUploadReceipt: (jobId: string) => void;
}) {
  const earnings = Math.round((job.livePrice || 0) * 0.8);
  const potentialRebate = Math.min((job.livePrice || 0) * 0.10, 25);
  
  const serviceLabels: Record<string, string> = {
    junk_removal: "Junk Removal",
    furniture_moving: "Furniture Moving",
    garage_cleanout: "Garage Cleanout",
    estate_cleanout: "Estate Cleanout",
  };

  // Calculate time since completion
  const completedAt = job.completedAt ? new Date(job.completedAt) : new Date();
  const hoursSinceCompletion = Math.floor((Date.now() - completedAt.getTime()) / (1000 * 60 * 60));
  const hoursRemaining = Math.max(0, 48 - hoursSinceCompletion);

  return (
    <Card className="p-5 border-green-500/30" data-testid={`card-completed-job-${job.id}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg font-semibold">Job #{job.id.slice(-4).toUpperCase()}</span>
          <Badge variant="secondary" className="bg-green-500/10 text-green-700">
            <CheckCircle className="w-3 h-3 mr-1" />
            COMPLETED
          </Badge>
        </div>
      </div>
      
      <div className="border-t border-b py-3 my-3">
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground">Earnings:</span>
          <span className="text-xl font-bold">${earnings}</span>
        </div>
      </div>

      {!hasExistingClaim ? (
        <div className="bg-green-500/10 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <Flag className="w-5 h-5 text-green-600" />
            <span className="font-bold text-green-700">EARN UP TO ${potentialRebate.toFixed(0)} MORE!</span>
          </div>
          
          <p className="text-sm text-muted-foreground mb-4">
            Upload dump receipt within {hoursRemaining > 0 ? `${hoursRemaining} hrs` : "48 hrs"} to get 10% rebate:
          </p>
          
          <Button 
            className="w-full mb-4"
            onClick={() => onUploadReceipt(job.id)}
            data-testid={`button-upload-receipt-${job.id}`}
          >
            <Camera className="w-4 h-4 mr-2" />
            Upload Receipt Photo
          </Button>
          
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Must show weight
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Must be from approved facility
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Must match job within 20%
            </li>
          </ul>
        </div>
      ) : (
        <div className="bg-muted/50 rounded-lg p-4 text-center">
          <Flag className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <p className="text-sm font-medium text-green-700">Receipt Submitted</p>
          <p className="text-xs text-muted-foreground">Pending admin review</p>
        </div>
      )}
      
      <p className="text-xs text-muted-foreground text-center mt-3">
        {serviceLabels[job.serviceType || ""] || job.serviceType} - {job.pickupAddress}
      </p>
    </Card>
  );
}

// Green Guarantee Rebate Section Component
function GreenGuaranteeSection({ haulerId, rebateBalance }: { haulerId: string; rebateBalance: number }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedJob, setSelectedJob] = useState<string>("");
  const [receiptUrl, setReceiptUrl] = useState<string>("");
  const [facilityName, setFacilityName] = useState<string>("");
  const [facilityAddress, setFacilityAddress] = useState<string>("");
  const [facilityType, setFacilityType] = useState<string>("recycling");
  const [receiptNumber, setReceiptNumber] = useState<string>("");
  const [receiptDate, setReceiptDate] = useState<string>("");
  const [receiptWeight, setReceiptWeight] = useState<string>("");
  const [feeCharged, setFeeCharged] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Get approved facilities list
  const { data: approvedFacilities } = useQuery<any[]>({
    queryKey: ["/api/facilities"],
  });

  // Get completed jobs for this hauler
  const { data: completedJobs } = useQuery<ServiceRequestWithDetails[]>({
    queryKey: ["/api/service-requests/hauler", haulerId],
    enabled: !!haulerId,
  });

  // Get existing rebate claims
  const { data: rebateClaims, isLoading: claimsLoading } = useQuery<any[]>({
    queryKey: ["/api/rebates/hauler", haulerId],
    queryFn: async () => {
      const res = await fetch(`/api/rebates/hauler/${haulerId}`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!haulerId,
  });

  // Handle facility selection from approved list
  const handleFacilitySelect = (facilityId: string) => {
    const facility = approvedFacilities?.find(f => f.id === facilityId);
    if (facility) {
      setFacilityName(facility.name);
      setFacilityAddress(`${facility.address}, ${facility.city}, ${facility.state} ${facility.zipCode || ""}`);
      setFacilityType(facility.facilityType);
      setValidationWarnings(prev => prev.filter(w => w !== 'unknown_facility'));
    }
  };

  // Check if entered facility matches an approved one
  const checkFacilityApproval = (name: string) => {
    if (!name || !approvedFacilities) return;
    const match = approvedFacilities.find(f => 
      f.name.toLowerCase().includes(name.toLowerCase()) ||
      name.toLowerCase().includes(f.name.toLowerCase())
    );
    if (!match) {
      if (!validationWarnings.includes('unknown_facility')) {
        setValidationWarnings(prev => [...prev, 'unknown_facility']);
      }
    } else {
      setValidationWarnings(prev => prev.filter(w => w !== 'unknown_facility'));
    }
  };

  // Get estimated weight for selected job
  const getEstimatedWeight = () => {
    const job = completedJobs?.find(j => j.id === selectedJob);
    if (!job) return 500;
    const loadWeights: Record<string, number> = { small: 200, medium: 500, large: 1000, extra_large: 2000 };
    return loadWeights[job.loadEstimate || "medium"] || 500;
  };

  // Check weight variance (20% tolerance)
  const checkWeightVariance = (weight: string) => {
    const numWeight = parseFloat(weight);
    if (isNaN(numWeight)) return;
    const estimated = getEstimatedWeight();
    const variance = Math.abs((numWeight - estimated) / estimated * 100);
    if (variance > 20) {
      if (!validationWarnings.includes('weight_variance')) {
        setValidationWarnings(prev => [...prev, 'weight_variance']);
      }
    } else {
      setValidationWarnings(prev => prev.filter(w => w !== 'weight_variance'));
    }
  };

  const submitClaimMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/rebates/claim", {
        serviceRequestId: selectedJob,
        haulerId,
        receiptUrl,
        facilityName,
        facilityAddress: facilityAddress || null,
        facilityType,
        receiptNumber: receiptNumber || null,
        receiptDate,
        receiptWeight: parseFloat(receiptWeight),
        feeCharged: feeCharged ? parseFloat(feeCharged) : null,
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/rebates/hauler", haulerId] });
      setSelectedJob("");
      setReceiptUrl("");
      setFacilityName("");
      setFacilityAddress("");
      setReceiptNumber("");
      setReceiptDate("");
      setReceiptWeight("");
      setFeeCharged("");
      setValidationWarnings([]);
      
      // Show validation results if there are flags
      if (data.validation?.flags?.length > 0) {
        toast({
          title: "Claim Submitted for Review",
          description: `Your claim has been flagged for manual review: ${data.validation.flags.join(', ')}`,
          variant: "default",
        });
      } else {
        toast({
          title: "Claim Submitted",
          description: "Your rebate claim is pending admin approval.",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit claim",
        variant: "destructive",
      });
    },
  });

  const handleReceiptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("directory", ".private/receipts");

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      const data = await res.json();
      if (data.path) {
        setReceiptUrl(data.path);
      }
    } catch (error) {
      console.error("Error uploading receipt:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const eligibleJobs = completedJobs?.filter(job => {
    const hasExistingClaim = rebateClaims?.some(claim => claim.serviceRequestId === job.id);
    return job.status === "completed" && !hasExistingClaim;
  }) || [];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Flag className="w-6 h-6 text-green-600" />
            Green Guarantee
          </h1>
          <p className="text-muted-foreground">
            100% Verified Proper Disposal - Earn 10% back (max $25) for recycling receipts
          </p>
        </div>
        <Card className="p-4 bg-green-500/10 border-green-500/30">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Your Rebate Balance</p>
            <p className="text-2xl font-bold text-green-600">${rebateBalance.toFixed(2)}</p>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Submit New Claim */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Submit Disposal Receipt
          </h3>
          
          <div className="space-y-4">
            <div>
              <Label>Select Completed Job</Label>
              <Select value={selectedJob} onValueChange={setSelectedJob}>
                <SelectTrigger data-testid="select-job">
                  <SelectValue placeholder="Choose a job..." />
                </SelectTrigger>
                <SelectContent>
                  {eligibleJobs.length === 0 ? (
                    <SelectItem value="none" disabled>No eligible jobs</SelectItem>
                  ) : (
                    eligibleJobs.map(job => (
                      <SelectItem key={job.id} value={job.id}>
                        {job.pickupAddress} - ${job.livePrice || 0}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Receipt Requirements Checklist */}
            <div className="bg-muted/50 p-3 rounded-lg text-sm">
              <p className="font-medium mb-2 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Receipt Must Show:
              </p>
              <ul className="space-y-1 text-muted-foreground">
                <li className={facilityName && facilityAddress ? "text-green-600" : ""}>
                  {facilityName && facilityAddress ? "✓" : "○"} Facility name/address
                </li>
                <li className={receiptDate ? "text-green-600" : ""}>
                  {receiptDate ? "✓" : "○"} Date & time (within 24 hours of job)
                </li>
                <li className={receiptWeight ? "text-green-600" : ""}>
                  {receiptWeight ? "✓" : "○"} Weight of load
                </li>
                <li className={feeCharged ? "text-green-600" : ""}>
                  {feeCharged ? "✓" : "○"} Fee charged
                </li>
                <li className={receiptNumber ? "text-green-600" : ""}>
                  {receiptNumber ? "✓" : "○"} Receipt number
                </li>
              </ul>
            </div>

            {/* Validation Warnings */}
            {(validationWarnings.length > 0 || (!receiptNumber && selectedJob) || (!feeCharged && selectedJob) || (!facilityAddress && selectedJob)) && (
              <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg text-sm">
                <p className="font-medium text-amber-700 flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" />
                  Missing Info May Delay Approval
                </p>
                <ul className="mt-1 text-amber-600 space-y-1">
                  {validationWarnings.includes('unknown_facility') && (
                    <li>Facility not in approved list - claim will require manual review</li>
                  )}
                  {validationWarnings.includes('weight_variance') && (
                    <li>Weight differs more than 20% from job estimate - claim may be flagged</li>
                  )}
                  {!receiptNumber && selectedJob && (
                    <li>Receipt number not provided - recommended for faster approval</li>
                  )}
                  {!feeCharged && selectedJob && (
                    <li>Fee charged not provided - recommended for verification</li>
                  )}
                  {!facilityAddress && selectedJob && (
                    <li>Facility address not provided - recommended for verification</li>
                  )}
                </ul>
              </div>
            )}

            {/* Approved Facility Selector */}
            <div>
              <Label>Select Approved Facility (Recommended)</Label>
              <Select onValueChange={handleFacilitySelect}>
                <SelectTrigger data-testid="select-approved-facility">
                  <SelectValue placeholder="Choose from approved facilities..." />
                </SelectTrigger>
                <SelectContent>
                  {approvedFacilities && approvedFacilities.length > 0 ? (
                    approvedFacilities.map(facility => (
                      <SelectItem key={facility.id} value={facility.id}>
                        {facility.name} ({facility.facilityType})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>No approved facilities loaded</SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">Or enter facility details manually below</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Facility Name <span className="text-red-500">*</span></Label>
                <Input 
                  placeholder="e.g., Orange County Landfill"
                  value={facilityName}
                  onChange={(e) => {
                    setFacilityName(e.target.value);
                    checkFacilityApproval(e.target.value);
                  }}
                  data-testid="input-facility-name"
                />
              </div>
              <div>
                <Label>Facility Type</Label>
                <Select value={facilityType} onValueChange={setFacilityType}>
                  <SelectTrigger data-testid="select-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="transfer_station">Transfer Station</SelectItem>
                    <SelectItem value="recycling">Recycling Center</SelectItem>
                    <SelectItem value="landfill">Landfill</SelectItem>
                    <SelectItem value="hazmat">Hazardous Waste</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Facility Address</Label>
              <Input 
                placeholder="e.g., 5901 Young Pine Rd, Orlando, FL 32829"
                value={facilityAddress}
                onChange={(e) => setFacilityAddress(e.target.value)}
                data-testid="input-facility-address"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Receipt Date & Time <span className="text-red-500">*</span></Label>
                <Input 
                  type="datetime-local"
                  value={receiptDate}
                  onChange={(e) => setReceiptDate(e.target.value)}
                  data-testid="input-receipt-date"
                />
              </div>
              <div>
                <Label>Receipt Number</Label>
                <Input 
                  placeholder="e.g., RC-12345"
                  value={receiptNumber}
                  onChange={(e) => setReceiptNumber(e.target.value)}
                  data-testid="input-receipt-number"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Weight from Receipt (lbs) <span className="text-red-500">*</span></Label>
                <Input 
                  type="number"
                  placeholder="e.g., 450"
                  value={receiptWeight}
                  onChange={(e) => {
                    setReceiptWeight(e.target.value);
                    checkWeightVariance(e.target.value);
                  }}
                  data-testid="input-weight"
                />
                {selectedJob && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Estimated: {getEstimatedWeight()} lbs (±20% accepted)
                  </p>
                )}
              </div>
              <div>
                <Label>Fee Charged ($)</Label>
                <Input 
                  type="number"
                  step="0.01"
                  placeholder="e.g., 35.00"
                  value={feeCharged}
                  onChange={(e) => setFeeCharged(e.target.value)}
                  data-testid="input-fee"
                />
              </div>
            </div>

            <div>
              <Label>Receipt Photo</Label>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleReceiptUpload}
              />
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                data-testid="button-upload-receipt"
              >
                {isUploading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Uploading...</>
                ) : receiptUrl ? (
                  <><CheckCircle className="w-4 h-4 mr-2 text-green-600" /> Receipt Uploaded</>
                ) : (
                  <><Camera className="w-4 h-4 mr-2" /> Upload Receipt Photo</>
                )}
              </Button>
            </div>

            <Button 
              className="w-full"
              disabled={!selectedJob || !receiptUrl || !facilityName || !receiptDate || !receiptWeight || submitClaimMutation.isPending}
              onClick={() => submitClaimMutation.mutate()}
              data-testid="button-submit-claim"
            >
              {submitClaimMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</>
              ) : (
                <>Submit for 10% Rebate</>
              )}
            </Button>
            <p className="text-xs text-center text-muted-foreground">
              Fields marked with <span className="text-red-500">*</span> are required
            </p>
          </div>
        </Card>

        {/* Claim History */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5" />
            Your Rebate Claims
          </h3>
          
          {claimsLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : rebateClaims && rebateClaims.length > 0 ? (
            <div className="space-y-3">
              {rebateClaims.map((claim: any) => (
                <div 
                  key={claim.id} 
                  className="p-3 border rounded-lg flex items-center justify-between"
                  data-testid={`claim-${claim.id}`}
                >
                  <div>
                    <p className="font-medium text-sm">{claim.facilityName || "Disposal Receipt"}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(claim.submittedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge 
                      variant={
                        claim.status === "approved" ? "default" : 
                        claim.status === "denied" ? "destructive" : 
                        "secondary"
                      }
                    >
                      {claim.status === "approved" && <CheckCircle className="w-3 h-3 mr-1" />}
                      {claim.status === "denied" && <X className="w-3 h-3 mr-1" />}
                      {claim.status === "pending" && <Clock className="w-3 h-3 mr-1" />}
                      {claim.status.charAt(0).toUpperCase() + claim.status.slice(1)}
                    </Badge>
                    {claim.rebateAmount && (
                      <p className="text-sm font-semibold text-green-600 mt-1">
                        +${claim.rebateAmount.toFixed(2)}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Flag className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No rebate claims yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                Submit disposal receipts to earn 10% back!
              </p>
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-6 p-5 bg-green-500/5 border-green-500/20">
        <h3 className="font-semibold mb-3 text-green-700 dark:text-green-400">How Green Guarantee Works</h3>
        <div className="grid sm:grid-cols-3 gap-4 text-sm">
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
              <span className="font-bold text-green-600">1</span>
            </div>
            <div>
              <p className="font-medium">Complete a Job</p>
              <p className="text-muted-foreground">Finish any junk removal or hauling job</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
              <span className="font-bold text-green-600">2</span>
            </div>
            <div>
              <p className="font-medium">Dispose Properly</p>
              <p className="text-muted-foreground">Take items to recycling or donation centers</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
              <span className="font-bold text-green-600">3</span>
            </div>
            <div>
              <p className="font-medium">Get 10% Back</p>
              <p className="text-muted-foreground">Upload receipt for instant rebate (max $25)</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function DashboardContent({ activeTab, setActiveTab }: { activeTab: string; setActiveTab: (tab: string) => void }) {
  const queryClient = useQueryClient();
  const [showGoOnlineDialog, setShowGoOnlineDialog] = useState(false);
  const [showNdaModal, setShowNdaModal] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>("");
  const [travelRadius, setTravelRadius] = useState<number>(25);
  const [locationConsent, setLocationConsent] = useState<boolean>(false);
  const wsRef = useRef<WebSocket | null>(null);
  const lastLocationBroadcast = useRef<number>(0);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);

  const [isConfirmingCall, setIsConfirmingCall] = useState(false);
  const { toast } = useToast();

  // Fetch hauler data first (needed for other queries)
  const { data: haulers } = useQuery<HaulerWithProfile[]>({
    queryKey: ["/api/haulers"],
  });

  const currentHauler = haulers?.[0];
  
  // Fetch active jobs for this hauler
  const { data: activeJobs, isLoading: activeJobsLoading, refetch: refetchActiveJobs } = useQuery<ServiceRequestWithDetails[]>({
    queryKey: ["/api/haulers", "active-jobs"],
    queryFn: async () => {
      const res = await fetch(`/api/haulers/${currentHauler?.id}/jobs/active`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!currentHauler?.id,
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  // Get the first active job (most PYCKERs work on one job at a time)
  const currentActiveJob = activeJobs?.[0];
  
  // Transform to ActiveJob format for compatibility
  const activeJob: ActiveJob | null = currentActiveJob ? {
    id: currentActiveJob.id,
    customerName: currentActiveJob.customer ? 
      `${currentActiveJob.customer.firstName || ''} ${currentActiveJob.customer.lastName || ''}`.trim() : 
      'Customer',
    customerPhone: currentActiveJob.customerPhone || '(555) 000-0000',
    pickupAddress: currentActiveJob.pickupAddress || '',
    pickupCity: currentActiveJob.pickupCity || '',
    pickupZip: currentActiveJob.pickupZip || '',
    serviceType: currentActiveJob.serviceType || '',
    loadEstimate: currentActiveJob.loadEstimate || 'medium',
    priceEstimate: currentActiveJob.livePrice || currentActiveJob.priceEstimate || 0,
    status: currentActiveJob.status || 'accepted',
    acceptedAt: currentActiveJob.acceptedAt || undefined,
    contactRequiredBy: currentActiveJob.contactRequiredBy || undefined,
    contactConfirmedAt: currentActiveJob.contactConfirmedAt || undefined,
    paymentStatus: currentActiveJob.paymentStatus || undefined,
  } : null;
  
  // Start job mutation
  const startJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      return apiRequest("POST", `/api/jobs/${jobId}/start`, {});
    },
    onSuccess: () => {
      refetchActiveJobs();
      toast({ title: "Job Started", description: "You can now begin working on this job" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to start job", variant: "destructive" });
    },
  });
  
  // Add adjustment mutation
  const addAdjustmentMutation = useMutation({
    mutationFn: async ({ jobId, adjustment }: { jobId: string; adjustment: { adjustmentType: string; itemName: string; priceChange: number; reason?: string } }) => {
      return apiRequest("POST", `/api/jobs/${jobId}/adjustments`, adjustment);
    },
    onSuccess: () => {
      toast({ title: "Adjustment Added", description: "Waiting for customer approval" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to add adjustment", variant: "destructive" });
    },
  });
  
  // Complete job mutation
  const completeJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      return apiRequest("POST", `/api/jobs/${jobId}/complete`, {});
    },
    onSuccess: (data) => {
      refetchActiveJobs();
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      toast({ title: "Job Completed!", description: "Payment has been captured successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to complete job", variant: "destructive" });
    },
  });
  
  // Update completion checklist mutation
  const updateCompletionMutation = useMutation({
    mutationFn: async ({ jobId, updates }: { jobId: string; updates: Record<string, any> }) => {
      return apiRequest("PATCH", `/api/jobs/${jobId}/completion`, updates);
    },
    onSuccess: () => {
      refetchActiveJobs();
    },
  });

  const handlePhotoUpload = async (files: FileList) => {
    if (!activeJob) return;
    setIsUploadingPhoto(true);
    try {
      const formData = new FormData();
      Array.from(files).forEach((file, idx) => {
        formData.append(`photo_${idx}`, file);
      });
      formData.append("jobId", activeJob.id);

      const response = await fetch("/api/jobs/upload-photos", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setUploadedPhotos(prev => [...prev, ...data.urls]);
      } else {
        const urls = Array.from(files).map(file => URL.createObjectURL(file));
        setUploadedPhotos(prev => [...prev, ...urls]);
      }
    } catch {
      const urls = Array.from(files).map(file => URL.createObjectURL(file));
      setUploadedPhotos(prev => [...prev, ...urls]);
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleReportIssue = async (issue: { type: string; description: string }) => {
    if (!activeJob) return;
    try {
      await apiRequest("POST", `/api/jobs/${activeJob.id}/report-issue`, issue);
      toast({ title: "Issue Reported", description: "Support will contact you shortly" });
    } catch {
      toast({ title: "Issue Reported", description: "Support will contact you shortly" });
    }
  };

  const handleCompleteJob = async () => {
    if (!activeJob) return;
    
    // First update completion checklist to mark work as completed
    await updateCompletionMutation.mutateAsync({
      jobId: activeJob.id,
      updates: { workCompleted: true, photosAfter: uploadedPhotos }
    });
    
    // Then complete the job
    completeJobMutation.mutate(activeJob.id);
    setUploadedPhotos([]);
  };

  const handleConfirmCall = async () => {
    if (!activeJob) return;
    setIsConfirmingCall(true);
    try {
      await apiRequest("POST", `/api/service-requests/${activeJob.id}/confirm-call`, {
        haulerId: currentHauler?.id,
      });
      refetchActiveJobs();
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
    } catch {
      toast({ title: "Call Confirmed", description: "Thank you for contacting the customer" });
    } finally {
      setIsConfirmingCall(false);
    }
  };
  
  const handleStartJob = () => {
    if (!activeJob) return;
    startJobMutation.mutate(activeJob.id);
  };
  
  const handleAddAdjustment = (itemName: string, priceChange: number, reason?: string) => {
    if (!activeJob) return;
    addAdjustmentMutation.mutate({
      jobId: activeJob.id,
      adjustment: {
        adjustmentType: priceChange >= 0 ? 'add_item' : 'remove_item',
        itemName,
        priceChange,
        reason,
      }
    });
  };

  const { data: pendingRequests, isLoading: requestsLoading } = useQuery<ServiceRequestWithDetails[]>({
    queryKey: ["/api/service-requests/pending"],
  });

  // Get completed jobs for this hauler
  const { data: completedJobs } = useQuery<ServiceRequestWithDetails[]>({
    queryKey: ["/api/service-requests/hauler", currentHauler?.profile?.id],
    enabled: !!currentHauler?.profile?.id,
  });

  // Get existing rebate claims to check which jobs have claims
  const { data: rebateClaims } = useQuery<any[]>({
    queryKey: ["/api/rebates/hauler", currentHauler?.profile?.id],
    queryFn: async () => {
      const res = await fetch(`/api/rebates/hauler/${currentHauler?.profile?.id}`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!currentHauler?.profile?.id,
  });

  // Get recent completed jobs eligible for receipt upload (within 48 hours)
  const recentCompletedJobs = completedJobs?.filter(job => {
    if (job.status !== "completed") return false;
    const completedAt = job.completedAt ? new Date(job.completedAt) : new Date();
    const hoursSinceCompletion = (Date.now() - completedAt.getTime()) / (1000 * 60 * 60);
    return hoursSinceCompletion <= 48;
  }) || [];

  // Function to navigate to rebates tab with pre-selected job
  const handleUploadReceipt = (jobId: string) => {
    setActiveTab("rebates");
    // The GreenGuaranteeSection will handle the job selection
  };
  const isAvailable = currentHauler?.profile?.isAvailable ?? false;

  const geoLocation = useGeoLocation(isAvailable, {
    enableHighAccuracy: true,
  });

  useEffect(() => {
    if (!isAvailable || !currentHauler?.id) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws?userId=${currentHauler.id}&role=hauler`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("PYCKER location WebSocket connected");
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("PYCKER location WebSocket disconnected");
    };

    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [isAvailable, currentHauler?.id]);

  useEffect(() => {
    if (!geoLocation.lat || !geoLocation.lng || !isAvailable) return;

    const now = Date.now();
    const hasActiveJob = !!currentActiveJob;
    const updateInterval = hasActiveJob ? 10000 : 30000;
    
    if (now - lastLocationBroadcast.current < updateInterval) return;
    lastLocationBroadcast.current = now;

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "location_update",
        data: {
          lat: geoLocation.lat,
          lng: geoLocation.lng,
          accuracy: geoLocation.accuracy,
          heading: geoLocation.heading,
          speed: geoLocation.speed,
        },
      }));
    }

    apiRequest("POST", "/api/haulers/update-location", {
      latitude: geoLocation.lat,
      longitude: geoLocation.lng,
      accuracy: geoLocation.accuracy,
    }).catch(err => console.error("Failed to update location:", err));
  }, [geoLocation.lat, geoLocation.lng, geoLocation.timestamp, isAvailable, currentActiveJob]);

  const { data: vehicles } = useQuery<PyckerVehicle[]>({
    queryKey: [`/api/haulers/${currentHauler?.profile?.id}/vehicles`],
    enabled: !!currentHauler?.profile?.id,
  });

  const goOnlineMutation = useMutation({
    mutationFn: async () => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      
      // Location consent is required per Florida labor law
      if (!locationConsent) {
        throw new Error("Location consent is required to go online");
      }
      
      // Get current location for GPS tracking
      const position = geoLocation.lat && geoLocation.lng ? 
        { latitude: geoLocation.lat, longitude: geoLocation.lng, accuracy: geoLocation.accuracy } :
        await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
          });
        }).then(pos => ({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        }));
      
      // First call the new GPS tracking endpoint (requires location consent)
      await apiRequest("POST", "/api/haulers/go-online", {
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: position.accuracy,
        locationConsent: locationConsent, // User explicitly consented via checkbox
      });
      
      // Then call the legacy endpoint to set vehicle and travel radius
      return apiRequest("POST", `/api/haulers/${currentHauler.profile.id}/go-online`, {
        vehicleId: selectedVehicleId,
        travelRadius,
      });
    },
    onSuccess: () => {
      setShowGoOnlineDialog(false);
      setLocationConsent(false); // Reset for next time
      queryClient.invalidateQueries({ queryKey: ["/api/haulers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/haulers/available"] });
      toast({
        title: "You're Online",
        description: "You are now visible to customers and can receive job requests.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to go online",
        description: error.message || "Please enable location services and try again.",
        variant: "destructive",
      });
    },
  });

  const goOfflineMutation = useMutation({
    mutationFn: async () => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      
      // Call the new GPS tracking endpoint to stop location tracking
      await apiRequest("POST", "/api/haulers/go-offline", {});
      
      // Then call the legacy endpoint
      return apiRequest("POST", `/api/haulers/${currentHauler.profile.id}/go-offline`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/haulers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/haulers/available"] });
      toast({
        title: "You're Offline",
        description: "Location tracking has stopped. You will not receive new job requests.",
      });
    },
  });

  const handleAvailabilityToggle = (checked: boolean) => {
    if (checked) {
      if (vehicles && vehicles.length > 0) {
        setSelectedVehicleId(vehicles[0].id);
        setTravelRadius(currentHauler?.profile?.activeTravelRadius || 25);
        setShowGoOnlineDialog(true);
      } else {
        goOnlineMutation.mutate();
      }
    } else {
      goOfflineMutation.mutate();
    }
  };

  const getVehicleLabel = (vehicle: PyckerVehicle) => {
    const parts = [];
    if (vehicle.vehicleName) parts.push(vehicle.vehicleName);
    else {
      if (vehicle.make) parts.push(vehicle.make);
      if (vehicle.model) parts.push(vehicle.model);
    }
    if (vehicle.year) parts.push(`(${vehicle.year})`);
    if (vehicle.hasTrailer && vehicle.trailerSize) parts.push(`w/ ${vehicle.trailerSize} trailer`);
    if (vehicle.isEnclosed) parts.push("- Enclosed");
    return parts.join(" ") || vehicle.vehicleType;
  };

  const acceptMutation = useMutation({
    mutationFn: async (requestId: string) => {
      return apiRequest("PATCH", `/api/service-requests/${requestId}`, {
        status: "assigned",
        assignedHaulerId: currentHauler?.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests/pending"] });
    },
  });

  const declineMutation = useMutation({
    mutationFn: async (requestId: string) => {
      return apiRequest("PATCH", `/api/service-requests/${requestId}`, {
        status: "cancelled",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests/pending"] });
    },
  });

  const { data: stripeStatus } = useQuery<{
    hasAccount: boolean;
    onboardingComplete: boolean;
    chargesEnabled?: boolean;
    payoutsEnabled?: boolean;
  }>({
    queryKey: ["/api/haulers", currentHauler?.profile?.id, "stripe-status"],
    queryFn: async () => {
      if (!currentHauler?.profile?.id) return { hasAccount: false, onboardingComplete: false };
      const res = await fetch(`/api/haulers/${currentHauler.profile.id}/stripe-status`);
      return res.json();
    },
    enabled: !!currentHauler?.profile?.id,
  });

  const stripeOnboardMutation = useMutation({
    mutationFn: async () => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      const res = await apiRequest("POST", `/api/haulers/${currentHauler.profile.id}/stripe-onboard`, {});
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
  });

  const { data: complianceStatus, isLoading: complianceLoading } = useQuery<{
    hasCardOnFile: boolean;
    backgroundCheckStatus: string;
    stripeOnboardingComplete: boolean;
    canAcceptJobs: boolean;
    unpaidPenaltiesCount: number;
    unpaidPenaltiesAmount: number;
    ndaAccepted: boolean;
    ndaAcceptedAt: string | null;
    ndaVersion: string | null;
  }>({
    queryKey: ["/api/haulers", currentHauler?.profile?.id, "compliance"],
    queryFn: async () => {
      if (!currentHauler?.profile?.id) return {
        hasCardOnFile: false,
        backgroundCheckStatus: "pending",
        stripeOnboardingComplete: false,
        canAcceptJobs: false,
        unpaidPenaltiesCount: 0,
        unpaidPenaltiesAmount: 0,
        ndaAccepted: false,
        ndaAcceptedAt: null,
        ndaVersion: null,
      };
      const res = await fetch(`/api/haulers/${currentHauler.profile.id}/compliance`);
      return res.json();
    },
    enabled: !!currentHauler?.profile?.id,
  });

  const setupCardMutation = useMutation({
    mutationFn: async () => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      const res = await apiRequest("POST", `/api/haulers/${currentHauler.profile.id}/setup-card`, {});
      return res.json();
    },
  });

  const backgroundCheckMutation = useMutation({
    mutationFn: async () => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      const res = await apiRequest("POST", `/api/haulers/${currentHauler.profile.id}/request-background-check`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/haulers", currentHauler?.profile?.id, "compliance"] });
    },
  });

  const acceptJobMutation = useMutation({
    mutationFn: async (requestId: string) => {
      if (!currentHauler?.id) throw new Error("No hauler");
      return apiRequest("POST", `/api/service-requests/${requestId}/accept`, {
        haulerId: currentHauler.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests/pending"] });
    },
  });

  // Languages for profile
  const languageOptions = [
    { id: "en", label: "English" },
    { id: "es", label: "Spanish" },
    { id: "pt", label: "Portuguese" },
    { id: "fr", label: "French" },
    { id: "ht", label: "Haitian Creole" },
    { id: "vi", label: "Vietnamese" },
    { id: "zh", label: "Chinese" },
  ];
  
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(
    currentHauler?.profile?.languagesSpoken || ["en"]
  );
  
  const updateLanguagesMutation = useMutation({
    mutationFn: async (languages: string[]) => {
      if (!currentHauler?.profile?.id) throw new Error("No profile");
      return apiRequest("PATCH", `/api/haulers/${currentHauler.profile.id}/profile`, {
        languagesSpoken: languages,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/haulers"] });
      toast({
        title: "Languages updated",
        description: "Your spoken languages have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update languages. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const toggleLanguage = (langId: string) => {
    const newLanguages = selectedLanguages.includes(langId)
      ? selectedLanguages.filter(l => l !== langId)
      : [...selectedLanguages, langId];
    
    // Must have at least one language
    if (newLanguages.length === 0) {
      toast({
        title: "At least one language required",
        description: "You must speak at least one language.",
        variant: "destructive",
      });
      return;
    }
    
    setSelectedLanguages(newLanguages);
    updateLanguagesMutation.mutate(newLanguages);
  };

  // Profile Section
  if (activeTab === "profile") {
    return (
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">My Profile</h1>
          <p className="text-muted-foreground">Manage your PYCKER profile and preferences</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={hauler1} alt={currentHauler?.profile?.companyName || 'PYCKER'} />
                <AvatarFallback className="text-xl">{currentHauler?.firstName?.charAt(0) || "P"}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-xl font-bold">{currentHauler?.profile?.companyName || "Your Company"}</h2>
                <Badge variant={currentHauler?.profile?.pyckerTier === "verified_pro" ? "default" : "secondary"}>
                  {currentHauler?.profile?.pyckerTier === "verified_pro" ? "Verified Pro" : "Independent PYCKER"}
                </Badge>
              </div>
            </div>
            
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Rating</span>
                <span className="font-medium flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  {currentHauler?.profile?.rating || 5.0} ({currentHauler?.profile?.reviewCount || 0} reviews)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Jobs Completed</span>
                <span className="font-medium">{currentHauler?.profile?.jobsCompleted || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Payout Rate</span>
                <span className="font-medium">{(currentHauler?.profile?.payoutPercentage || 0.75) * 100}%</span>
              </div>
            </div>
          </Card>
          
          <Card className="p-5">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Languages I Speak
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Select all languages you can communicate with customers in. This helps us match you with customers who prefer your language.
            </p>
            
            <div className="flex flex-wrap gap-2">
              {languageOptions.map((lang) => (
                <button
                  key={lang.id}
                  type="button"
                  className={`px-4 py-2 rounded-lg border text-sm font-medium transition-all hover-elevate ${
                    selectedLanguages.includes(lang.id)
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-background"
                  }`}
                  onClick={() => toggleLanguage(lang.id)}
                  disabled={updateLanguagesMutation.isPending}
                  data-testid={`toggle-lang-${lang.id}`}
                >
                  {selectedLanguages.includes(lang.id) && (
                    <CheckCircle className="w-4 h-4 inline mr-1" />
                  )}
                  {lang.label}
                </button>
              ))}
            </div>
            
            {updateLanguagesMutation.isPending && (
              <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" />
                Saving...
              </p>
            )}
          </Card>
          
          <Card className="p-5 lg:col-span-2">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Package className="w-5 h-5" />
              Service Types
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Jobs you're willing to accept. Contact support to update.
            </p>
            
            <div className="flex flex-wrap gap-2">
              {(currentHauler?.profile?.serviceTypes || ["junk_removal", "furniture_moving", "garage_cleanout", "estate_cleanout"]).map((service) => (
                <Badge key={service} variant="secondary" className="text-sm">
                  {{
                    junk_removal: "Junk Removal",
                    furniture_moving: "Furniture Moving",
                    garage_cleanout: "Garage Cleanout",
                    estate_cleanout: "Estate Cleanout",
                    truck_unloading: "U-Haul/Truck Unloading",
                  }[service] || service}
                </Badge>
              ))}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  // Green Guarantee Rebate Section
  if (activeTab === "rebates") {
    return (
      <GreenGuaranteeSection 
        haulerId={currentHauler?.profile?.id || ""} 
        rebateBalance={currentHauler?.profile?.rebateBalance || 0}
      />
    );
  }

  if (activeTab === "requests") {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Job Requests</h1>
            <p className="text-muted-foreground">
              {pendingRequests?.length || 0} available jobs in your area
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          {requestsLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-20 w-full" />
              </Card>
            ))
          ) : pendingRequests && pendingRequests.length > 0 ? (
            pendingRequests.map((request) => (
              <JobRequestCard
                key={request.id}
                request={request}
                onAccept={() => acceptJobMutation.mutate(request.id)}
                onDecline={() => declineMutation.mutate(request.id)}
                canAcceptJobs={complianceStatus?.canAcceptJobs ?? false}
                isAccepting={acceptJobMutation.isPending}
              />
            ))
          ) : (
            <Card className="col-span-full p-12 text-center">
              <ClipboardList className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold mb-2">No job requests right now</h3>
              <p className="text-muted-foreground">
                New requests will appear here. Make sure you're set to available!
              </p>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Welcome back, {currentHauler?.profile?.companyName || "PYCKER"}!</h1>
          <p className="text-muted-foreground">Here's what's happening today</p>
        </div>
        <Card className={`p-4 ${isAvailable ? "bg-green-500/10 border-green-500/30" : "bg-muted"}`}>
          <div className="flex items-center gap-4">
            <div className={`w-3 h-3 rounded-full ${isAvailable ? "bg-green-500 animate-pulse" : "bg-muted-foreground"}`} />
            <div>
              <p className={`font-semibold ${isAvailable ? "text-green-600 dark:text-green-400" : "text-muted-foreground"}`}>
                {isAvailable ? "You're Online" : "You're Offline"}
              </p>
              <p className="text-xs text-muted-foreground">
                {isAvailable ? (
                  <>
                    {vehicles?.find(v => v.id === currentHauler?.profile?.activeVehicleId)?.vehicleType || "Available"} 
                    {currentHauler?.profile?.activeTravelRadius && ` • ${currentHauler.profile.activeTravelRadius} mi radius`}
                    {geoLocation.isTracking && (
                      <span className="ml-2 text-green-600 dark:text-green-400">
                        • GPS Active
                      </span>
                    )}
                    {geoLocation.error && (
                      <span className="ml-2 text-amber-600 dark:text-amber-400">
                        • GPS Error
                      </span>
                    )}
                  </>
                ) : "Go online to receive jobs"}
              </p>
            </div>
            <Switch 
              checked={isAvailable} 
              onCheckedChange={handleAvailabilityToggle}
              disabled={goOnlineMutation.isPending || goOfflineMutation.isPending}
              data-testid="switch-availability"
              className="ml-2"
            />
          </div>
        </Card>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Today's Earnings</span>
            <DollarSign className="w-4 h-4 text-muted-foreground" />
          </div>
          <p className="text-2xl font-bold">$347</p>
          <p className="text-xs text-status-online">+12% from yesterday</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Jobs Completed</span>
            <CheckCircle className="w-4 h-4 text-muted-foreground" />
          </div>
          <p className="text-2xl font-bold">4</p>
          <p className="text-xs text-muted-foreground">2 more scheduled</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Pending Requests</span>
            <ClipboardList className="w-4 h-4 text-muted-foreground" />
          </div>
          <p className="text-2xl font-bold">{pendingRequests?.length || 0}</p>
          <button 
            className="text-xs text-primary hover:underline"
            onClick={() => setActiveTab("requests")}
          >
            View all
          </button>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Rating</span>
            <Star className="w-4 h-4 text-muted-foreground" />
          </div>
          <p className="text-2xl font-bold">{currentHauler?.profile?.rating || 4.9}</p>
          <p className="text-xs text-muted-foreground">
            {currentHauler?.profile?.reviewCount || 247} reviews
          </p>
        </Card>
      </div>

      {/* Active Job Section */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Current Job</h2>
        {activeJobsLoading ? (
          <Card className="p-5">
            <Skeleton className="h-48 w-full" />
          </Card>
        ) : activeJob ? (
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Show Start Job button if job is accepted but not yet in_progress */}
            {activeJob.status === 'accepted' || activeJob.status === 'assigned' ? (
              <Card className="p-5" data-testid="card-start-job">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Truck className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Job Ready to Start</h3>
                      <p className="text-sm text-muted-foreground">{activeJob.customerName}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">${activeJob.priceEstimate}</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex items-start gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                    <span>{activeJob.pickupAddress}, {activeJob.pickupCity} {activeJob.pickupZip}</span>
                  </div>
                </div>
                <Button 
                  className="w-full" 
                  onClick={handleStartJob}
                  disabled={startJobMutation.isPending}
                  data-testid="button-start-job"
                >
                  {startJobMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <CheckCircle className="w-4 h-4 mr-2" />
                  )}
                  Start Job - I've Arrived
                </Button>
              </Card>
            ) : (
              <ActiveJobCard
                job={activeJob}
                onPhotoUpload={handlePhotoUpload}
                onReportIssue={handleReportIssue}
                onCompleteJob={handleCompleteJob}
                onConfirmCall={handleConfirmCall}
                isUploading={isUploadingPhoto}
                uploadedPhotos={uploadedPhotos}
                isConfirmingCall={isConfirmingCall}
              />
            )}
            <ItemVerificationCard
              originalItems={currentActiveJob?.selectedItems?.map((item: any) => ({
                id: item.id || item.name,
                label: item.label || item.name,
                quantity: item.quantity || 1,
                price: item.price || 0,
              })) || []}
              onVerified={(verified, adjustments) => {
                if (adjustments.totalAdjustment > 0) {
                  adjustments.added.forEach(item => {
                    handleAddAdjustment(item.label, item.price * item.quantity, "Extra item found on site");
                  });
                }
                if (verified && adjustments.totalAdjustment === 0) {
                  handleStartJob();
                }
              }}
            />
          </div>
        ) : (
          <Card className="p-8 text-center">
            <Truck className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold mb-2">No Active Job</h3>
            <p className="text-muted-foreground">
              Accept a job request to get started
            </p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setActiveTab("requests")}
              data-testid="button-view-requests"
            >
              View Job Requests
            </Button>
          </Card>
        )}
      </div>

      {/* Recent Completed Jobs - Receipt Upload Prompt */}
      {recentCompletedJobs.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Flag className="w-5 h-5 text-green-600" />
            Recent Completed Jobs - Earn Extra!
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentCompletedJobs.slice(0, 3).map((job) => {
              const hasExistingClaim = rebateClaims?.some(claim => claim.serviceRequestId === job.id);
              return (
                <CompletedJobCard
                  key={job.id}
                  job={job}
                  hasExistingClaim={hasExistingClaim || false}
                  onUploadReceipt={handleUploadReceipt}
                />
              );
            })}
          </div>
          {recentCompletedJobs.length > 3 && (
            <div className="text-center mt-4">
              <Button 
                variant="outline" 
                onClick={() => setActiveTab("rebates")}
                data-testid="button-view-all-completed"
              >
                View All {recentCompletedJobs.length} Completed Jobs
              </Button>
            </div>
          )}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <h2 className="text-lg font-semibold mb-4">Recent Job Requests</h2>
          <div className="space-y-4">
            {requestsLoading ? (
              <Card className="p-5">
                <Skeleton className="h-24 w-full" />
              </Card>
            ) : pendingRequests && pendingRequests.length > 0 ? (
              pendingRequests.slice(0, 2).map((request) => (
                <JobRequestCard
                  key={request.id}
                  request={request}
                  onAccept={() => acceptJobMutation.mutate(request.id)}
                  onDecline={() => declineMutation.mutate(request.id)}
                  canAcceptJobs={complianceStatus?.canAcceptJobs ?? false}
                  isAccepting={acceptJobMutation.isPending}
                />
              ))
            ) : (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">No pending requests</p>
              </Card>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
          <Card className="p-4 space-y-3">
            <Button variant="outline" className="w-full justify-start" data-testid="button-update-location">
              <MapPin className="w-4 h-4 mr-2" />
              Update Location
            </Button>
            <Button variant="outline" className="w-full justify-start" data-testid="button-view-schedule">
              <Calendar className="w-4 h-4 mr-2" />
              View Schedule
            </Button>
            <Button variant="outline" className="w-full justify-start" data-testid="button-earnings">
              <DollarSign className="w-4 h-4 mr-2" />
              View Earnings
            </Button>
            <Separator />
            <Button variant="outline" className="w-full justify-start" data-testid="button-support">
              <Phone className="w-4 h-4 mr-2" />
              Contact Support
            </Button>
          </Card>

          <h2 className="text-lg font-semibold mt-6 mb-4">Payment Setup</h2>
          <Card className="p-4">
            {stripeStatus?.onboardingComplete ? (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="font-medium text-green-600 dark:text-green-400">Payments Enabled</p>
                  <p className="text-sm text-muted-foreground">You can receive payouts for completed jobs</p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                  </div>
                  <div>
                    <p className="font-medium">Set Up Payments</p>
                    <p className="text-sm text-muted-foreground">
                      Complete Stripe onboarding to receive payouts for your jobs. You'll earn 75% of each job.
                    </p>
                  </div>
                </div>
                <Button 
                  className="w-full"
                  onClick={() => stripeOnboardMutation.mutate()}
                  disabled={stripeOnboardMutation.isPending}
                  data-testid="button-stripe-onboard"
                >
                  {stripeOnboardMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4 mr-2" />
                      Set Up Stripe Account
                      <ExternalLink className="w-3 h-3 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </Card>

          <h2 className="text-lg font-semibold mt-6 mb-4">Compliance Checklist</h2>
          <Card className="p-4 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  complianceStatus?.hasCardOnFile 
                    ? "bg-green-100 dark:bg-green-900/30" 
                    : "bg-yellow-100 dark:bg-yellow-900/30"
                }`}>
                  <CreditCard className={`w-4 h-4 ${
                    complianceStatus?.hasCardOnFile 
                      ? "text-green-600 dark:text-green-400" 
                      : "text-yellow-600 dark:text-yellow-400"
                  }`} />
                </div>
                <div>
                  <p className="font-medium text-sm">Card on File</p>
                  <p className="text-xs text-muted-foreground">Required for accountability</p>
                </div>
              </div>
              {complianceStatus?.hasCardOnFile ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setupCardMutation.mutate()}
                  disabled={setupCardMutation.isPending}
                  data-testid="button-add-card"
                >
                  {setupCardMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Add Card"}
                </Button>
              )}
            </div>

            <Separator />

            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  complianceStatus?.backgroundCheckStatus === "clear" 
                    ? "bg-green-100 dark:bg-green-900/30" 
                    : "bg-yellow-100 dark:bg-yellow-900/30"
                }`}>
                  <Shield className={`w-4 h-4 ${
                    complianceStatus?.backgroundCheckStatus === "clear" 
                      ? "text-green-600 dark:text-green-400" 
                      : "text-yellow-600 dark:text-yellow-400"
                  }`} />
                </div>
                <div>
                  <p className="font-medium text-sm">Background Check</p>
                  <p className="text-xs text-muted-foreground">
                    {complianceStatus?.backgroundCheckStatus === "clear" 
                      ? "Verified" 
                      : complianceStatus?.backgroundCheckStatus === "pending"
                      ? "Required to accept jobs"
                      : "In progress"}
                  </p>
                </div>
              </div>
              {complianceStatus?.backgroundCheckStatus === "clear" ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => backgroundCheckMutation.mutate()}
                  disabled={backgroundCheckMutation.isPending}
                  data-testid="button-background-check"
                >
                  {backgroundCheckMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Start Check"}
                </Button>
              )}
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  complianceStatus?.ndaAccepted 
                    ? "bg-green-100 dark:bg-green-900/30" 
                    : "bg-yellow-100 dark:bg-yellow-900/30"
                }`}>
                  <FileText className={`w-4 h-4 ${
                    complianceStatus?.ndaAccepted 
                      ? "text-green-600 dark:text-green-400" 
                      : "text-yellow-600 dark:text-yellow-400"
                  }`} />
                </div>
                <div>
                  <p className="font-medium text-sm">Non-Solicitation Agreement</p>
                  <p className="text-xs text-muted-foreground">
                    {complianceStatus?.ndaAccepted 
                      ? `Signed on ${new Date(complianceStatus.ndaAcceptedAt!).toLocaleDateString()}` 
                      : "Required to accept jobs"}
                  </p>
                </div>
              </div>
              {complianceStatus?.ndaAccepted ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setShowNdaModal(true)}
                  data-testid="button-sign-nda"
                >
                  Sign Agreement
                </Button>
              )}
            </div>

            {complianceStatus?.unpaidPenaltiesCount ? (
              <>
                <Separator />
                <div className="flex items-center gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="font-medium text-sm text-red-600 dark:text-red-400">Outstanding Penalties</p>
                    <p className="text-xs text-muted-foreground">
                      {complianceStatus.unpaidPenaltiesCount} unpaid (${complianceStatus.unpaidPenaltiesAmount})
                    </p>
                  </div>
                </div>
              </>
            ) : null}

            <Separator />

            <div className="flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: complianceStatus?.canAcceptJobs ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)' }}>
              <UserCheck className={`w-5 h-5 ${complianceStatus?.canAcceptJobs ? "text-green-500" : "text-red-500"}`} />
              <div>
                <p className={`font-medium text-sm ${complianceStatus?.canAcceptJobs ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                  {complianceStatus?.canAcceptJobs ? "Ready to Accept Jobs" : "Cannot Accept Jobs Yet"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {complianceStatus?.canAcceptJobs 
                    ? "All requirements met" 
                    : "Complete all items above"}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={showGoOnlineDialog} onOpenChange={setShowGoOnlineDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Go Online</DialogTitle>
            <DialogDescription>
              Select the vehicle you're using today and how far you're willing to travel for jobs.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label>Select Vehicle</Label>
              {vehicles && vehicles.length > 0 ? (
                <Select value={selectedVehicleId} onValueChange={setSelectedVehicleId}>
                  <SelectTrigger data-testid="select-active-vehicle">
                    <SelectValue placeholder="Choose a vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map((vehicle) => (
                      <SelectItem key={vehicle.id} value={vehicle.id}>
                        <div className="flex flex-col">
                          <span>{getVehicleLabel(vehicle)}</span>
                          <span className="text-xs text-muted-foreground">
                            {vehicle.isEnclosed ? "Enclosed" : "Open"} 
                            {vehicle.hasTrailer && ` + ${vehicle.trailerSize || "Trailer"}`}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-sm text-muted-foreground">No vehicles registered. You can still go online.</p>
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Travel Radius</Label>
                <span className="text-lg font-bold">{travelRadius} miles</span>
              </div>
              <Slider
                value={[travelRadius]}
                onValueChange={([val]) => setTravelRadius(val)}
                min={5}
                max={100}
                step={5}
                className="w-full"
                data-testid="slider-travel-radius"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>5 mi</span>
                <span>50 mi</span>
                <span>100 mi</span>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="location-consent"
                  checked={locationConsent}
                  onChange={(e) => setLocationConsent(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded border-input"
                  data-testid="checkbox-location-consent"
                />
                <div className="space-y-1">
                  <Label htmlFor="location-consent" className="text-sm font-medium cursor-pointer">
                    I consent to GPS location tracking while online
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Per Florida labor law, you may decline location tracking. Your location will only be shared 
                    while you're online and will be automatically deleted after 48 hours. Location data is used 
                    to connect you with nearby customers.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowGoOnlineDialog(false)} data-testid="button-cancel-go-online">
              Cancel
            </Button>
            <Button 
              onClick={() => goOnlineMutation.mutate()}
              disabled={goOnlineMutation.isPending || (!selectedVehicleId && vehicles && vehicles.length > 0) || !locationConsent}
              data-testid="button-confirm-go-online"
            >
              {goOnlineMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Going online...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Go Online
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <NdaAgreementModal
        open={showNdaModal}
        onOpenChange={setShowNdaModal}
        pyckerName={currentHauler?.firstName && currentHauler?.lastName 
          ? `${currentHauler.firstName} ${currentHauler.lastName}`
          : currentHauler?.email || "PYCKER"}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ["/api/haulers", currentHauler?.profile?.id, "compliance"] });
        }}
      />
    </div>
  );
}

export default function HaulerDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();

  const { data: haulers } = useQuery<HaulerWithProfile[]>({
    queryKey: ["/api/haulers"],
  });

  const currentHauler = haulers?.[0];

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = "/login";
    }
  }, [authLoading, isAuthenticated]);

  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center" data-testid="page-loading">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full" data-testid="page-hauler-dashboard">
        <Sidebar>
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary text-primary-foreground">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-lg font-bold">uPYCK</span>
                <p className="text-xs text-muted-foreground">PYCKER Portal</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        isActive={activeTab === item.id}
                        onClick={() => setActiveTab(item.id)}
                        data-testid={`nav-${item.id}`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                        {item.badge && (
                          <Badge className="ml-auto" variant="secondary">
                            {item.badge}
                          </Badge>
                        )}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="p-4">
            <div className="flex items-center gap-3 p-3 bg-sidebar-accent rounded-lg">
              <Avatar>
                <AvatarImage src={hauler1} alt={currentHauler?.firstName || 'Hauler'} />
                <AvatarFallback>{currentHauler?.firstName?.charAt(0) || "H"}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">
                  {currentHauler?.profile?.companyName || "Hauler"}
                </p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-status-online" />
                  Online
                </p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b bg-background">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" data-testid="button-notifications">
                <Bell className="w-5 h-5" />
              </Button>
            </div>
          </header>

          <main className="flex-1 overflow-auto bg-muted/30">
            <DashboardContent activeTab={activeTab} setActiveTab={setActiveTab} />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
