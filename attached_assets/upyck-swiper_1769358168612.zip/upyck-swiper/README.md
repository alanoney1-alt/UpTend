# uPYCK Swiper - Pycker Matching Feature

A modern, Tinder-style swipe interface for matching customers with pyckers, combined with an AI-powered quick match system.

## Features

✅ **Hybrid Matching System**
- Quick Match: AI-powered recommendations (top 3 pyckers)
- Browse Mode: Swipe through all available pyckers
- Shortlist Review: Review and select from swiped-right pyckers

✅ **Professional Design**
- Clean, modern UI matching uPYCK brand
- Mobile-responsive
- Smooth animations and transitions
- Accessible and intuitive

✅ **Smart Recommendations**
- Sorts by availability, rating, and proximity
- Displays verified pyckers
- Shows badges and specialties
- Real-time availability status

## Installation in Replit

### Step 1: Install Dependencies

In your Replit Shell, run:

```bash
npm install react-tinder-card
```

### Step 2: Add Files to Your Project

Copy these files into your Replit project:

```
src/
├── components/
│   ├── MatchingFlow.jsx
│   ├── MatchingFlow.css
│   ├── PyckerSwiper.jsx
│   ├── PyckerSwiper.css
│   ├── QuickMatch.jsx
│   ├── QuickMatch.css
│   ├── ShortlistReview.jsx
│   └── ShortlistReview.css
```

### Step 3: Import in Your Main App

Replace the sample implementation in `App.jsx` with your actual data flow:

```javascript
import MatchingFlow from './components/MatchingFlow';

function YourBookingPage() {
  const [availablePyckers, setAvailablePyckers] = useState([]);
  const [jobDetails, setJobDetails] = useState({});

  // Fetch your pyckers from API
  useEffect(() => {
    fetchAvailablePyckers().then(setAvailablePyckers);
  }, []);

  const handlePyckerSelected = (pycker) => {
    // Your booking logic here
    createBooking(pycker, jobDetails);
  };

  return (
    <MatchingFlow
      availablePyckers={availablePyckers}
      jobDetails={jobDetails}
      onPyckerSelected={handlePyckerSelected}
      onCancel={() => navigate('/dashboard')}
    />
  );
}
```

## Component API

### MatchingFlow
Main orchestrator component that handles the entire matching flow.

**Props:**
- `availablePyckers` (array, required): List of available pyckers
- `jobDetails` (object, required): Job information to display
- `onPyckerSelected` (function, required): Callback when pycker is selected
- `onCancel` (function, optional): Callback for cancellation

### PyckerSwiper
Tinder-style swipe interface for browsing pyckers.

**Props:**
- `availablePyckers` (array, required): List of pyckers to swipe through
- `onComplete` (function, required): Callback with shortlisted pyckers
- `onSkip` (function, required): Callback to skip to quick match

### QuickMatch
Shows top 3 AI-recommended pyckers.

**Props:**
- `recommendedPyckers` (array, required): Top 3 recommended pyckers
- `onSelectPycker` (function, required): Callback when pycker selected
- `onBrowseAll` (function, required): Callback to browse all
- `onBack` (function, required): Callback to go back

### ShortlistReview
Review screen for shortlisted pyckers from swipe interface.

**Props:**
- `shortlist` (array, required): Shortlisted pyckers
- `onSelectPycker` (function, required): Callback when pycker selected
- `onBack` (function, required): Callback to return to swiping

## Data Structure

Your pycker objects should follow this structure:

```javascript
{
  id: string,              // Unique identifier
  name: string,            // Pycker's name
  photo: string,           // Profile photo URL
  rating: number,          // Rating (0-5)
  completedJobs: number,   // Number of completed jobs
  specialty: string,       // Main specialty
  distance: number,        // Distance in miles
  hourlyRate: number,      // Hourly rate in dollars
  available: boolean,      // Available today?
  verified: boolean,       // Verified pycker?
  badges: string[],        // Array of badge labels
  bio: string             // Short bio/description
}
```

## Customization

### Colors
Update the primary color in all CSS files (currently `#4CAF50` for green):

```css
/* Change all instances of #4CAF50 to your brand color */
background: #4CAF50; /* Your color here */
```

### Card Content
Modify `PyckerSwiper.jsx` to add/remove fields shown on cards:
- Add new stats in the `pycker-stats` section
- Customize badge display
- Add custom fields from your database

### Matching Algorithm
Update `getRecommendedPyckers()` in `MatchingFlow.jsx` to customize how pyckers are ranked:

```javascript
const getRecommendedPyckers = () => {
  return availablePyckers
    .sort((a, b) => {
      // Your custom sorting logic
      // Example: Prioritize verified pyckers
      if (a.verified !== b.verified) return a.verified ? -1 : 1;
      // Then by rating
      return b.rating - a.rating;
    })
    .slice(0, 3);
};
```

## Mobile Optimization

All components are fully responsive with breakpoints at:
- 600px: Mobile phones
- 768px: Tablets
- Default: Desktop

## Testing

Test the swipe mechanics:
1. Try swiping left and right
2. Use the button controls
3. Test on mobile devices
4. Verify shortlist functionality
5. Test quick match selection

## Performance Tips

- Lazy load pycker photos
- Limit initial load to 20-30 pyckers
- Implement pagination if you have 50+ pyckers
- Cache pycker data in localStorage for returning users

## Next Steps

1. Connect to your backend API for real pycker data
2. Implement actual booking logic in `handlePyckerSelected`
3. Add loading states while fetching pyckers
4. Implement error handling for failed API calls
5. Add analytics tracking for swipe metrics
6. Consider A/B testing Quick Match vs Browse usage

## Support

For questions or issues with implementation, refer to:
- [react-tinder-card docs](https://github.com/3DJakob/react-tinder-card)
- Your uPYCK backend API documentation

---

Built for uPYCK - You Pick, We Haul
