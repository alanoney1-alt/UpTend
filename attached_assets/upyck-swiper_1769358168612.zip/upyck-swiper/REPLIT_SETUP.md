# Quick Setup Guide for Replit

## Step-by-Step Implementation

### 1. Create New Replit Project
- Go to Replit.com
- Click "Create Repl"
- Choose "React + Vite" template
- Name it "upyck-swiper" or similar

### 2. Install Dependencies

Open the Shell and run:
```bash
npm install react-tinder-card
```

### 3. Copy Files

Copy all the files from this package into your Replit:

**Root files:**
- `package.json`
- `vite.config.js`
- `index.html`

**Source files (in `src/` folder):**
- `main.jsx`
- `App.jsx`
- `App.css`
- `MatchingFlow.jsx`
- `MatchingFlow.css`
- `PyckerSwiper.jsx`
- `PyckerSwiper.css`
- `QuickMatch.jsx`
- `QuickMatch.css`
- `ShortlistReview.jsx`
- `ShortlistReview.css`

### 4. File Structure

Your Replit should look like this:

```
upyck-swiper/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── MatchingFlow.jsx
    ├── MatchingFlow.css
    ├── PyckerSwiper.jsx
    ├── PyckerSwiper.css
    ├── QuickMatch.jsx
    ├── QuickMatch.css
    ├── ShortlistReview.jsx
    └── ShortlistReview.css
```

### 5. Run the App

Click the green "Run" button in Replit, or in Shell:
```bash
npm run dev
```

The app will start on `http://localhost:5173` (or your Replit URL)

### 6. Test the Features

You should now be able to:

**Initial Selection Screen:**
- See "Quick Match" and "Browse All Pyckers" options
- View top rated pyckers preview

**Quick Match Flow:**
- Click "Quick Match"
- See top 3 recommended pyckers
- Select one and book

**Browse/Swipe Flow:**
- Click "Browse All Pyckers"
- Swipe left/right on pycker cards
- Or use the ❌ and ❤️ buttons
- Review your shortlist
- Select final pycker

### 7. Customize for Your Needs

**Update Colors:**
Find and replace `#4CAF50` with your brand color in all CSS files.

**Connect Your API:**
In `App.jsx`, replace `samplePyckers` with:

```javascript
const [pyckers, setPyckers] = useState([]);

useEffect(() => {
  fetch('YOUR_API_ENDPOINT/pyckers')
    .then(res => res.json())
    .then(data => setPyckers(data));
}, []);
```

**Update Job Details:**
Replace `sampleJobDetails` with actual job data from your booking flow.

### 8. Common Issues & Solutions

**Issue: "react-tinder-card not found"**
Solution: Make sure you ran `npm install react-tinder-card`

**Issue: Styles not loading**
Solution: Verify all `.css` files are imported in their corresponding `.jsx` files

**Issue: Images not showing**
Solution: Replace sample image URLs with your actual pycker photos

**Issue: Swipe not working on mobile**
Solution: Ensure you're using touch events - the library handles this automatically

### 9. Integration with Existing uPYCK App

If you already have a uPYCK app, you can integrate this by:

1. Copy all component files into your existing `src/components/` folder
2. Import `MatchingFlow` where you want to use it (probably after job details are collected)
3. Pass your real data as props:

```javascript
// In your booking flow
import MatchingFlow from './components/MatchingFlow';

function BookingPage() {
  const [jobData, setJobData] = useState(null);
  const [availablePyckers, setAvailablePyckers] = useState([]);

  // After user enters job details...
  const handleJobSubmitted = async (jobDetails) => {
    setJobData(jobDetails);
    // Fetch available pyckers for this job
    const pyckers = await fetchAvailablePyckers(jobDetails);
    setAvailablePyckers(pyckers);
  };

  return (
    <>
      {!jobData ? (
        <JobDetailsForm onSubmit={handleJobSubmitted} />
      ) : (
        <MatchingFlow
          availablePyckers={availablePyckers}
          jobDetails={jobData}
          onPyckerSelected={handleBooking}
          onCancel={() => setJobData(null)}
        />
      )}
    </>
  );
}
```

### 10. Next Steps

- [ ] Add loading states for API calls
- [ ] Implement error handling
- [ ] Add analytics tracking (swipes, selections, etc.)
- [ ] A/B test Quick Match vs Browse usage
- [ ] Add pycker availability calendar
- [ ] Implement real-time availability updates
- [ ] Add push notifications for pycker confirmations

### Support Resources

- **react-tinder-card docs:** https://github.com/3DJakob/react-tinder-card
- **Vite docs:** https://vitejs.dev/
- **React docs:** https://react.dev/

---

Need help? Review the README.md for detailed component documentation.
